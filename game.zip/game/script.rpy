﻿# Despues de San Fermin


# Characters
define l = Character("利希", color="#d44b4b")
define m = Character("马塔拉佐", color="#6b8fd6")
define u = Character("Urko", color="#8abf7c")
define s = Character("助教", color="#aaaaaa")
define r = Character("记者", color="#dddddd")
define n = Character(None)
transform fit_screen:
    xysize (config.screen_width, config.screen_height)

# Route variables
default trust = 0
default anger = 0
default soft = 0
default tease = 0
default italian = 0
default football = 0
default morale = 0
default points = 24
default survival = 0
default cup_distance = 0

default urko_trust = 0
default urko_jealousy = 0

default first_language_choice = ""
default winter_choice = ""
default derby_mood = ""

# Persistent unlock flags
default persistent.roma_summer_unlock = False
default persistent.future_unlock = False
default persistent.xmas_unlock = False
default persistent.threefourteen_unlock = False
default persistent.key_before_unlock = False
default persistent.derby_if_unlock = False


image pamplona_menu = "images/pamplona.png"

label start:

    scene black
    with fade

    show expression "images/pamplona.png" at fit_screen
    with dissolve

    menu:
        "请选择："

        "开始主线":
            jump chapter_1

        "EXTRA":
            jump extra_menu

# ============================================================
# CHAPTER 1: 礼貌陌生
# ============================================================

label chapter_1:

    scene black
    with fade

    n "第一章：第一次见面"
    n "那天不是比赛日。"
    n "是西甲教练会议。"
    n "会议室冷气开得很足，咖啡很难喝，所有人都穿着差不多的外套。"
    n "利希听说皇家社会来了一个意裔。"
    n "于是第一次见面时，他出于礼貌，很自然地选择了意大利语。"

    l "Piacere."
    n "很高兴认识你。"

    n "马塔拉佐停了半秒。"
    n "不是没听懂。"
    n "更像是大脑还停在西语工作频道，突然被人切进了意大利语。"

    m "……抱歉。"

    l "……"

    menu:
        "我："

        "立刻切回西语":
            $ trust += 1
            $ first_language_choice = "polite"
            l "很高兴认识你。"
            m "我也是。"
            n "他像是终于把工作语言切了回来。"

        "继续用意大利语试探":
            $ italian += 1
            $ tease += 1
            $ first_language_choice = "italian"
            l "Non parli italiano?"
            n "你不说意大利语？"
            m "会一点。只是刚刚没反应过来。"
            l "……你不是意裔？"
            m "是。问题是现在工作里很少用。"
            n "他说得很认真，反而有点好笑。"

        "调侃他":
            $ tease += 2
            $ first_language_choice = "tease"
            l "意裔，但听不懂意大利语？"
            m "小时候经常有人这么说。"
            n "他没有生气。"
            n "反而笑了一下。"
            n "那一秒，利希意识到这个人可能比看起来难对付。"

        "假装什么都没发生":
            $ anger += 1
            $ first_language_choice = "awkward"
            l "算了，还是正常说吧。"
            m "这可能更安全一点。"
            n "安全。"
            n "这个词让利希稍微多看了他一眼。"

    n "会议开始前，他们只聊了三分钟。"
    n "内容非常职业。"
    n "训练负荷。"
    n "新赛季节奏。"
    n "西甲裁判尺度。"
    n "没有暧昧。"
    n "没有私人话题。"
    n "只有两个成年人第一次见面时该有的距离。"

    menu:
        "离开前，我决定："

        "礼貌道别":
            $ trust += 1
            l "场边见。"
            m "我会记住的。"

        "补一句意大利语":
            $ italian += 1
            l "Alla prossima."
            n "下次见。"
            m "...Alla prossima."
            n "他重复得很慢。"
            n "发音不算好，但很努力。"

        "什么都不说":
            $ anger += 1
            n "我拿起文件直接走了。"
            n "走到门口时，我还是感觉到有人看了过来。"

    n "那天之后。"
    n "利希对马塔拉佐的第一印象只有三个词。"
    n "高。"
    n "礼貌。"
    n "被意大利语突袭时会卡壳。"

    jump chapter_2


# ============================================================
# CHAPTER 2: 职业熟人
# ============================================================

label chapter_2:

    scene black
    with fade

    n "第二章：职业熟人"
    n "第二次见到马塔拉佐，是在联赛。"
    n "皇家社会客场。"
    n "赛前握手区，灯光很白。"
    n "利希本来准备按普通流程打招呼。"
    n "结果马塔拉佐先开口了。"

    m "Buonasera."

    n "发音有一点硬。"
    n "像训练过。"
    n "也像临场背出来。"

    menu:
        "我："

        "忍住不笑":
            $ trust += 1
            l "Buonasera."
            n "马塔拉佐看起来明显放心了。"

        "直接笑出来":
            $ tease += 2
            l "你回去练了？"
            m "练了一点。"
            l "练得挺明显。"
            m "这么糟？"
            l "很努力。"
            n "他笑了一下。"
            n "这次不是社交礼貌。"

        "切回英语":
            $ anger += 1
            l "正常说就行。"
            m "你是在救我。"
            l "我是在救我的耳朵。"
            m "公平。"

        "用西语回":
            $ football += 1
            l "Buenas noches."
            m "这个我听懂了。"
            l "恭喜。"

    n "比赛踢得很紧。"
    n "皇家社会控球。"
    n "奥萨苏纳逼抢。"
    n "第六十七分钟，马塔拉佐在场边做了一个手势。"
    n "利希看懂了。"
    n "那不是换人。"
    n "是压迫方向调整。"

    menu:
        "我选择："

        "立刻跟着调整":
            $ football += 2
            n "我让边路收回来。"
            n "三分钟后，局面重新稳住。"

        "不动，观察他第二步":
            $ trust += 1
            $ football += 1
            n "我没有急着改。"
            n "他看了过来。"
            n "像知道我在等。"

        "故意反着来":
            $ tease += 1
            n "我压了另一侧。"
            n "马塔拉佐愣了一下。"
            n "然后笑了。"

    n "比赛最后 1:1。"
    n "不算好。"
    n "也不算坏。"
    n "赛后通道里，他递来一份文件。"

    m "你上次把这个落在会议室了。"

    l "你带了多久？"

    m "久到看起来很负责。"

    l "……谢谢。"

    n "这就是第一条 WhatsApp 的来源。"
    n "不是暧昧。"
    n "是文件。"
    n "非常无聊。"
    n "也非常合理。"

    n "晚上，手机亮起。"

    m "比赛不错。你的文件也活下来了。"

    menu:
        "我回复："

        "谢谢":
            $ trust += 1
            l "谢谢。"
            m "很职业。"
            l "当然。"

        "比赛一般":
            $ football += 1
            l "比赛一般。"
            m "你标准很高。"
            l "你的意大利语标准比较低。"
            m "这个也是真的。"

        "别借文件聊天":
            $ tease += 2
            l "别借文件聊天。"
            m "那我下次得换个借口。"
            l "你可以不要有下次。"
            m "记下了。暂时不采纳。"

        "不回":
            $ anger += 1
            n "我把手机扣过去。"
            n "十分钟后。"
            m "这么糟？"
            n "我还是没回。"

    n "从那天开始，他们偶尔会聊。"
    n "大多数时候是足球。"
    n "阵型。"
    n "比赛。"
    n "裁判。"
    n "偶尔是语言。"
    n "利希发现马塔拉佐的意大利语不是不会。"
    n "只是像一扇很久没推开的门。"
    n "马塔拉佐也发现利希只在想逗人的时候才切意大利语。"
    n "于是很公平。"

    jump chapter_3


# ============================================================
# CHAPTER 3: 罗马冬日，分歧点
# ============================================================

label chapter_3:

    scene black
    with fade

    n "第三章：罗马冬日"
    n "冬歇期。"
    n "利希短暂回了一趟罗马。"
    n "这本来不该成为任何事件。"
    n "但那天罗马下雪了。"
    n "很少见。"
    n "雪落在窗边，灯光变得很软。"

    n "手机亮起。"

    m "罗马冷吗？"

    l "你自己不会看天气？"

    m "天气软件不会用三种语言骂我。"

    menu:
        "我："

        "回他照片":
            $ soft += 1
            n "我随手拍了一张窗外。"
            l "下雪了。"
            m "我知道。"
            l "那你还问。"
            m "想听你说。"

        "只回一句冷":
            $ anger += 1
            l "冷。"
            m "听起来很严重。"
            l "你很烦。"

        "问他圣塞冷不冷":
            $ trust += 1
            l "圣塞冷不冷？"
            m "看起来比罗马好一点。"
            l "少骗人。"

        "不回":
            $ anger += 1
            n "我没回。"
            n "五分钟后。"
            m "还活着？"
            n "很烦。"

    n "凌晨。"
    n "他打来视频。"

    m "开视频。"

    l "不要。"

    m "我想看看雪。"

    l "天气预报没有雪？"

    m "不一样。天气预报里没有你。"

    menu:
        "我决定："

        "开视频":
            $ soft += 2
            $ trust += 1
            n "我还是开了视频。"
            m "你的头发很灾难。"
            l "关你什么事。"
            m "练了一点。"

        "镜头对窗外":
            $ tease += 1
            n "我把镜头对准窗外。"
            m "那是罗马。"
            l "你不是要看雪？"
            m "我说的是罗马人。"
            l "滚。"

        "只露脸一秒":
            $ tease += 2
            n "我把镜头转回来一秒。"
            n "然后又转走。"
            m "太短了。"
            l "你要求很多。"
            m "只对重要的事这样。"

        "挂掉":
            $ anger += 2
            n "我挂了。"
            n "三秒后，消息跳出来。"
            m "很没礼貌。"
            l "职业边界。"
            m "凌晨一点半的职业边界？"

    n "视频最后还是接着。"
    n "话题从天气滑到足球。"
    n "又从足球滑到语言。"
    n "马塔拉佐试着说意大利语。"
    n "说得很慢。"
    n "像怕踩错每一个音节。"

    m "Mi... sei mancato."

    n "我想你了。"

    n "利希愣了一下。"

    menu:
        "我最后说："

        "你真的很烦":
            $ tease += 1
            $ winter_choice = "annoying"
            l "你真的很烦。"
            m "你没挂电话。"
            l "我手滑。"
            m "四十分钟也算早点睡？"

        "早点睡":
            $ trust += 1
            $ winter_choice = "sleep"
            l "早点睡。"
            m "你先睡。"
            l "你先。"
            m "职业僵局。"

        "再说一句意大利语":
            $ italian += 3
            $ soft += 2
            $ trust += 1
            $ winter_choice = "italian"
            l "再说一句意大利语。"
            m "你在考我？"
            l "对。"
            m "Allora... resta al caldo."
            n "那就待在暖和的地方。"
            l "还行。"
            m "只是还行？"
            l "及格。"
            $ persistent.roma_summer_unlock = True
            n "【？？？已被发现】"
            n "某个夏天，在远处亮了一下。"

        "问他是不是想我":
            $ soft += 1
            $ tease += 1
            $ winter_choice = "miss"
            l "你想我？"
            n "那边沉默了很久。"
            m "比我预想的严重。"
            l "……谁问你这个了。"

    if trust >= 4 and soft >= 3:
        $ persistent.threefourteen_unlock = True

    if italian >= 3:
        $ persistent.future_unlock = True

    n "罗马冬日结束后。"
    n "利希回到潘普洛纳。"
    n "而现实也回到了原来的重量。"

    menu:
        "继续："

        "进入现实足球线":
            jump chapter_4

        "打开 EXTRA 看看":
            jump extra_menu


# ============================================================
# HIDDEN ROUTE: Roma d'estate
# ============================================================

label roma_summer_route:

    scene black
    with fade

    n "【隐藏路线】"
    n "Roma d'estate"
    n "罗马夏日"
    n "这是一段本不该发生的夏天。"

    n "六月。"
    n "罗马 38℃。"
    n "热得连石墙都像在呼吸。"
    n "利希回罗马短住。"
    n "他以为这次终于能安静几天。"
    n "门铃响了。"

    l "……？"

    n "门外。"
    n "马塔拉佐戴着太阳镜。"
    n "黑 T。"
    n "行李箱。"
    n "像某种完全不合理的度假事故。"

    l "你为什么在罗马？？？"

    m "独处时间。"

    l "你把冬天那句话记到现在？"

    m "有些句子很重要。"

    menu:
        "我："

        "让他进来":
            $ soft += 2
            l "进来。别站门口丢人。"
            m "这是允许。"
            l "这是嫌你挡路。"

        "先骂他":
            $ tease += 2
            l "你疯了。"
            m "练了一点。"
            l "你每次都这个答案。"
            m "它一直是真的。"

        "问他住哪":
            $ trust += 1
            l "你住哪？"
            m "酒店。"
            l "很好。"
            m "你听起来有点失望。"
            l "没有。"

    n "罗马夏天和冬天不一样。"
    n "冬天适合把话藏在雪里。"
    n "夏天不行。"
    n "太热。"
    n "什么都会被晒出来。"

    n "第一天，他们去吃 gelato。"
    n "马塔拉佐选了太甜的口味。"
    n "利希嘲笑他五分钟。"

    menu:
        "夜里，我选择："

        "带他去台伯河边":
            $ soft += 2
            n "夜风终于凉了一点。"
            m "你是在这里长大的？"
            l "算是。"
            m "难怪你骂人这么漂亮。"
            l "你闭嘴。"

        "带他去小时候的街区":
            $ trust += 2
            n "巷子窄。"
            n "灯很旧。"
            n "马塔拉佐走得很慢，像怕踩坏什么。"
            m "谢谢你带我看。"
            l "少突然认真。"

        "哪都不去，躲空调":
            $ tease += 1
            n "空调声音很吵。"
            n "两个人坐在客厅。"
            n "谁都没有提为什么不各回各的地方。"

    n "第三天晚上，空调坏了。"
    n "罗马热得像一只不肯睡觉的兽。"
    n "凌晨两点，利希去厨房喝水。"
    n "马塔拉佐也在那里。"

    m "睡不着？"

    l "你也没睡。"

    m "我在等，看你会不会出来。"

    l "你这句话听起来很可疑。"

    m "这是实话。更糟。"

    n "那一夜他们聊了很久。"
    n "不是调情。"
    n "是足球。"
    n "是教练。"
    n "是赢球之后没人知道的疲惫。"
    n "也是输球之后不得不第二天继续工作的荒谬。"

    menu:
        "天亮前，我说："

        "你明天就走吧":
            $ anger += 1
            l "你明天就走吧。"
            m "你想让我走吗？"
            l "我在陈述事实。"
            m "你今晚不太会说事实。"

        "再待一天":
            $ soft += 3
            l "再待一天。"
            n "马塔拉佐很久没说话。"
            m "用意大利语？"
            l "别得寸进尺。"

        "Resta ancora":
            $ italian += 3
            $ soft += 4
            l "Resta ancora."
            n "再待一会。"
            n "马塔拉佐愣住。"
            m "你清醒的时候说了。"
            l "所以？"
            m "所以我有麻烦了。"

    n "【隐藏路线：夏后 开启】"
    n "这个夏天以后，某些德比注定不会再按原来的方式发生。"

    return


# ============================================================
# CHAPTER 4: 保级战争
# ============================================================

label chapter_4:

    scene black
    with fade

    n "第四章：保级战争"
    n "二月。"
    n "奥萨苏纳，24 分。"
    n "第 17。"
    n "降级区就在身后。"
    n "会议室灯开到凌晨。"
    n "积分榜、伤病报告、赛程表，全摊在桌上。"
    n "贝尼托的名字后面还是 unavailable。"
    n "不是刚伤。"
    n "是已经缺了太久。"
    n "球队早就开始习惯没有他。"
    n "但习惯不代表不疼。"

    s "我们得开始算分了。"

    l "安全线呢？"

    s "今年可能要 40。甚至 42。"

    n "手机震了一下。"
    n "Matarazzo。"

    m "积分榜怎么样？"

    menu:
        "我："

        "不看":
            $ cup_distance += 1
            n "我没有看。"
            n "现在没有时间处理别人的关心。"

        "回：很烂":
            $ trust += 1
            l "很烂。"
            m "真诚。"
            l "你问的。"

        "回：关你什么事":
            $ tease += 1
            l "关你什么事。"
            m "一点职业好奇。"
            l "少来。"

        "回：你先管好国王杯":
            $ football += 1
            l "你先管好国王杯。"
            m "在试。"

    n "第二天，战术会。"
    n "保级队没有浪漫。"
    n "只有选择。"

    menu:
        "下一轮，我选择："

        "稳守反击":
            $ survival += 2
            $ points += 1
            n "比赛不好看。"
            n "但拿到一分。"
            n "保级路上，一分也能救命。"

        "高位逼抢":
            $ football += 2
            $ morale += 1
            n "前二十分钟很好。"
            n "后面很累。"
            n "最后 2:2。"
            $ points += 1

        "定位球搏命":
            $ survival += 1
            $ morale += 1
            n "角球。混战。第二点。"
            n "球进了。"
            $ points += 3

        "五后卫保命":
            $ survival += 1
            $ anger += 1
            n "媒体骂得很难听。"
            n "但更衣室知道。"
            n "有些比赛就是不能死。"
            $ points += 1

    n "发布会。"

    r "你觉得奥萨苏纳还能保级吗？"

    menu:
        "我回答："

        "稳住军心":
            $ morale += 2
            l "我们会留下。"
            r "你确定？"
            l "我必须确定。"

        "阴阳怪气":
            $ tease += 1
            l "如果你有更好的积分，我很愿意听。"
            n "记者席安静了两秒。"

        "承认困难":
            $ trust += 1
            l "很难。"
            l "但难不代表结束。"

        "发疯一点":
            $ anger += 1
            l "下一场赢了你们是不是就换个问题？"
            n "新闻标题立刻有了。"

    n "三月。"
    n "皇家社会进入国王杯决赛。"
    n "新闻刷屏。"
    n "马塔拉佐发来消息。"

    m "我们进决赛了。"

    menu:
        "我："

        "回恭喜":
            $ trust += 1
            l "恭喜。"
            m "谢谢。"
            n "很普通。"
            n "普通到有点陌生。"

        "只点开，不回":
            $ cup_distance += 2
            n "已读。"
            n "不回。"
            n "不是故意。"
            n "只是桌上还有下一轮对手的录像。"

        "回：我没空":
            $ anger += 1
            l "我没空。"
            m "我知道。"
            n "这句“我知道”比恭喜更难处理。"

    n "现实把人压得很薄。"
    n "薄到感情只能夹在赛程表和伤病报告之间。"

    if points >= 28:
        $ persistent.key_before_unlock = True

    jump chapter_5


# ============================================================
# CHAPTER 5: 德比失踪夜（现实版）
# ============================================================

label chapter_5:

    scene black
    with fade

    n "第五章：德比失踪夜"
    n "德比那天，利希已经连续三晚没睡好。"
    n "不是因为马塔拉佐。"
    n "至少不全是。"
    n "积分榜像一张贴在眼皮后的纸。"
    n "闭眼也还在那里。"

    n "赛前，手机亮起。"

    m "祝你好运。"

    menu:
        "我："

        "不回":
            $ derby_mood = "cold"
            n "我没回。"

        "回：你也是":
            $ derby_mood = "soft"
            $ trust += 1
            l "你也是。"
            m "很职业。"

        "回：少来":
            $ derby_mood = "tease"
            $ tease += 1
            l "少来。"
            m "这才像你。"

    n "比赛踢得很硬。"
    n "没有罗马冬日。"
    n "没有玩笑。"
    n "只有铲断、回追、第二落点和裁判哨。"

    menu:
        "下半场，我选择："

        "保平":
            $ survival += 1
            $ points += 1
            n "0:0。"
            n "不好看。"
            n "但活着。"

        "赌一把赢":
            $ football += 2
            n "第八十七分钟，反击差一点成了。"
            n "下一分钟，皇家社会也差一点杀死比赛。"
            n "最后还是平。"
            $ points += 1

        "换上年轻人":
            $ morale += 2
            n "年轻人跑得很凶。"
            n "全场起立鼓掌。"
            n "比分没有变，但更衣室像活了一点。"
            $ points += 1

    n "赛后，利希没去看马塔拉佐。"
    n "他只想回更衣室。"
    n "但通道拐角。"
    n "有人等在那里。"

    m "你看起来糟透了。"

    l "谢谢。你也很烦。"

    m "这点倒是一直没变。"

    menu:
        "我："

        "让他走":
            $ anger += 1
            l "你该去发布会。"
            m "我知道。"
            l "那就去。"
            n "他没动。"

        "问他为什么来":
            $ soft += 1
            l "你来干什么。"
            m "确认你还站得住。"
            l "我不是小孩。"
            m "不。你更糟，只是更会装。"

        "沉默":
            $ trust += 1
            n "我没说话。"
            n "他也没急。"
            n "成年人最糟糕的一点。"
            n "就是他们知道什么时候不该追问。"

    n "工作人员在远处喊。"

    s "Mister！发布会！"

    n "马塔拉佐没有回头。"

    m "五分钟。"

    l "你又失踪。"

    m "不是所有人都有。"

    n "这一句话太轻。"
    n "轻得像没有落地。"
    n "但利希还是听见了。"

    if soft >= 5 or trust >= 6:
        $ persistent.derby_if_unlock = True

    menu:
        "最后，我："

        "推开他":
            l "别挡路。"
            m "好。"
            n "他让开。"
            n "反而更难受。"

        "低声说谢谢":
            $ soft += 2
            l "谢谢。"
            m "为什么？"
            l "别让我解释。"
            m "好。"

        "用意大利语骂他":
            $ italian += 1
            l "Sei fastidioso."
            n "你很烦。"
            m "这句我听懂了。"

    n "那晚没有视频。"
    n "没有开车。"
    n "没有钥匙。"
    n "只有两个主教练，各自回到自己的现实里。"

    jump chapter_6


# ============================================================
# CHAPTER 6: 国王杯冠军夜
# ============================================================

label chapter_6:

    scene black
    with fade

    n "第六章：国王杯冠军夜"
    n "皇家社会夺冠那天，潘普洛纳在下雨。"
    n "奥萨苏纳第二天还有训练。"
    n "利希看了十分钟决赛。"
    n "然后关掉。"
    n "不是不想看。"
    n "是不敢再多看。"

    n "凌晨。"
    n "手机亮起。"

    m "我们赢了。"

    n "就两个词。"
    n "像从另一个世界传来。"

    menu:
        "我："

        "回恭喜":
            $ trust += 1
            l "恭喜。"
            m "谢谢。"
            n "对话停在这里。"
            n "礼貌得像第一章。"

        "已读不回":
            $ cup_distance += 2
            n "我看着那条消息。"
            n "最后把手机扣在桌上。"

        "只发一个杯子 emoji":
            $ tease += 1
            l "🏆"
            m "这几乎算温柔了。"
            l "别得寸进尺。"

        "关机":
            $ cup_distance += 3
            n "我关了机。"
            n "第二天醒来时，世界没有变轻。"

    n "那之后，马塔拉佐发消息的频率变低。"
    n "利希回消息的速度更低。"
    n "不是谁故意疏远。"
    n "只是一个人在庆祝冠军。"
    n "另一个人在计算保级。"
    n "成年人最残酷的距离，有时候只是赛程不同。"

    if cup_distance >= 4:
        $ persistent.future_unlock = True

    jump chapter_7


# ============================================================
# CHAPTER 7: 保级终章
# ============================================================

label chapter_7:

    scene black
    with fade

    n "第七章：保级终章"
    n "最后几轮。"
    n "每一分都像从石头缝里抠出来。"
    n "第 38 轮前。"
    n "奥萨苏纳还没完全安全。"
    n "会议室里没人说废话。"

    s "最后一场。"
    s "我们需要至少一分。"

    menu:
        "最终战术："

        "死守一分":
            $ survival += 2
            $ points += 1
            n "比赛像一场漫长的拔河。"
            n "终场哨响。"
            n "0:0。"

        "定位球抢开局":
            $ football += 2
            $ points += 3
            n "第十二分钟，角球。"
            n "混战。"
            n "球进了。"
            n "之后每一分钟都像一年。"

        "正常踢":
            $ morale += 1
            $ points += 1
            n "没有奇迹。"
            n "但也没有崩溃。"
            n "这就是保级队最奢侈的胜利。"

        "冒险进攻":
            $ football += 3
            n "场面很好。"
            n "心脏很差。"
            n "最后靠门将救了一次命。"
            $ points += 1

    if points >= 40:
        jump ending_survival
    else:
        jump ending_survival_edge


label ending_survival:

    scene black
    with fade

    n "保级成功。"
    n "没有奖杯。"
    n "没有彩带。"
    n "只有更衣室里突然安静下来的呼吸声。"
    n "利希坐了很久。"
    n "手机亮起。"

    m "你也赢了。"

    n "你也赢了。"

    menu:
        "我："

        "回他":
            l "只是留下。"
            m "有时候这更难。"
            n "利希看着这句话。"
            n "很久。"

        "不回":
            n "我没有回。"
            n "但这一次不是逃避。"
            n "只是太累了。"

    n "【主线结局：留下】"
    return


label ending_survival_edge:

    scene black
    with fade

    n "奥萨苏纳还是留下了。"
    n "惊险。狼狈。几乎称不上胜利。"
    n "但留下就是留下。"
    n "深夜。"
    n "手机亮起。"

    m "还站得住吗？"

    l "勉强。"

    m "那就算。"

    n "【主线结局：勉强站着】"
    return


# ============================================================
# EXTRA: all slots are ???. Click reveals preview sentence, then locked/unlocked.
# ============================================================


label extra_menu:

    scene black
    with fade

    show expression "images/extra_bg.png" at fit_screen
    with dissolve

    centered "【EXTRA】"

    if persistent.roma_summer_unlock:

        menu:
            "选择一个记忆碎片："

            "Roma d'estate":
                jump roma_summer_route

            "返回主菜单":
                jump start

    else:

        menu:
            "选择一个记忆碎片："

            "？？？":
                jump extra_slot_summer

            "返回主菜单":
                jump start
label extra_slot_summer:

    scene expression "images/summer_bg.png"
    with fade

    n "「有些夏天，本不该发生。」"

    if persistent.roma_summer_unlock:
        n "【隐藏路线】"
        n "Roma d'estate"
        menu:
            "进入？"
            "进入":
                jump roma_summer_route
            "返回":
                jump extra_menu
    else:
        n "尚未解锁。"
        jump extra_menu

label extra_slot_future:

    scene rain_bg
    with fade

    n "「有人会在暴雨里带你回家。」"

    if persistent.future_unlock:
        n "【回忆特典】"
        n "洞悉未来"
        menu:
            "进入？"
            "进入":
                jump future_special
            "返回":
                jump extra_menu
    else:
        n "尚未解锁。"
        jump extra_menu


label extra_slot_xmas:

    scene xmas_bg
    with fade

    n "「圣诞以后，有人开始舍不得放手。」"

    if persistent.xmas_unlock:
        n "【回忆特典】"
        n "Buon Natale"
        menu:
            "进入？"
            "进入":
                jump xmas_special
            "返回":
                jump extra_menu
    else:
        n "尚未解锁。"
        jump extra_menu


label extra_slot_threefourteen:

    scene bed
    with fade

    n "「凌晨三点，总有人还醒着。」"

    if persistent.threefourteen_unlock:
        n "【回忆特典】"
        n "凌晨 3:14"
        menu:
            "进入？"
            "进入":
                jump threefourteen_special
            "返回":
                jump extra_menu
    else:
        n "尚未解锁。"
        jump extra_menu

label extra_slot_key_before:

    scene carbg
    with fade

    n "「楼下停了一辆没有离开的车。」"

    if persistent.key_before_unlock:
        n "【回忆特典】"
        n "备用钥匙之前"

        menu:
            "进入？"

            "进入":
                jump key_before_special

            "返回":
                jump extra_menu

    else:
        n "尚未解锁。"

    jump extra_menu


label extra_slot_derby_if:

    scene sadar
    with fade

    n "「总有一场德比会失控。」"

    if persistent.derby_if_unlock:
        n "【IF 特典】"
        n "德比特别篇"
        menu:
            "进入？"
            "进入":
                jump derby_if_special
            "返回":
                jump extra_menu
    else:
        n "尚未解锁。"
        jump extra_menu


# ============================================================
# EXTRA CONTENTS
# ============================================================

label future_special:

    scene black
    with fade

    n "【洞悉未来】"
    n "凌晨 2:17。"
    n "视频没挂。"
    n "马塔拉佐看着屏幕里睡着的人。"
    n "有一点不对。"
    n "不是情绪。"
    n "也不是天气。"
    n "像心脏忽然空了一拍。"

    menu:
        "他决定："

        "去找":
            n "他拿钥匙。"
            n "拿外套。"
            n "圣塞巴斯蒂安到潘普洛纳。"
            n "雨越下越大。"
            n "训练基地旁，铁栏边。"
            n "利希蹲在那里。"
            n "湿透。"
            n "没有鞋。"
            n "像根本没醒。"
            m "利希。看我。"
            n "没有回应。"
            n "马塔拉佐终于明白。"
            n "梦游。"
            n "他把人抱起来，裹进外套。"
            l "……回家。"
            m "嗯。先回家。"
            n "但他没说，是他的。"
            return

        "放过":
            n "他关掉视频。"
            n "那种不安没有消失。"
            return


label xmas_special:

    scene black
    with fade

    n "【Buon Natale】"
    n "圣塞巴斯蒂安下雨了。"
    n "利希拖着行李箱站在门口。"

    m "这次记得带睡衣了吗？"

    l "你是不是有病。"

    m "有一点。"

    n "夜里。"
    n "电影没看完。"
    n "利希睡着。"
    n "凌晨两点，卧室门开了。"
    n "梦游人士抱着枕头站在门口。"

    m "……过来。"

    n "他熟练钻进被子。"
    n "低声意大利语。"

    l "Fa freddo..."

    n "好冷。"

    m "毯子在你身上。"

    l "Non basta..."

    n "不够。"

    n "第二天料理台。"
    n "一口早餐，一个吻。"

    l "你到底在干嘛。"

    m "哄你吃饭。"

    n "晚上。"
    n "小罗马人困得快睡着。"

    l "Così resti qui..."

    n "这样你就会待在这里。"
    n "马塔拉佐合上电脑。"
    n "圣诞夜，梦游人士又赢一次。"

    return


label threefourteen_special:

    scene black
    with fade

    n "【凌晨 3:14】"
    n "正文里没有写的那一段。"
    n "视频没挂。"
    n "利希睡着了。"
    n "马塔拉佐原本应该挂断。"
    n "但屏幕里的人翻身时，手指抓住了被角。"
    n "像抓住什么会离开的东西。"

    l "Sei qui..."

    n "你在。"

    n "梦话。"
    n "意大利语。"
    n "太轻。"
    n "却足够让一个成年人做出很不成熟的决定。"

    n "凌晨 3:14。"
    n "圣塞巴斯蒂安。"
    n "车钥匙被拿起。"

    return


label key_before_special:

    scene black
    with fade

    n "【备用钥匙之前】"
    n "那是还没有钥匙之前。"
    n "马塔拉佐确实路过了潘普洛纳。"
    n "也确实停在楼下。"
    n "两个小时。"
    n "冷咖啡。"
    n "没发出去的消息。"

    m "醒着吗？"

    n "删掉。"

    m "我就在附近。"

    n "删掉。"

    m "算了。"

    n "还是删掉。"

    n "成年人最擅长克制。"
    n "也最擅长把克制伪装成路过。"

    return


label derby_if_special:

    scene black
    with fade

    n "【德比特别篇】"
    n "这是某一场不算数的德比。"
    n "利希选择了完全针对马塔拉佐的战术。"
    n "皇家社会输了。"
    n "赛后，失踪的人变成了马塔拉佐。"

    l "你输了还笑？"

    m "你看了我九十分钟。"

    l "我是为了赢。"

    m "我知道。"

    m "所以我喜欢。"

    n "工作人员在远处喊。"
    n "两个主教练都假装没听见。"

    return
