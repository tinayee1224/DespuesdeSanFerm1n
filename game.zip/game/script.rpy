﻿# Despues de San Fermin


# Characters
define l = Character("利希", color="#d44b4b")
define m = Character("马塔拉佐", color="#6b8fd6")
define b = Character("贝尼托", color="#8abf7c")
define s = Character("助教", color="#aaaaaa")
define r = Character("记者", color="#dddddd")
define h = Character("林孔", color="#dddddd")
define n = Character(None)

transform fit_screen:
    xysize (config.screen_width, config.screen_height)

# Route variables
default trust = 0
default anger = 0
default soft = 0
default tease = 0
default italian = 0
default football = 0
default morale = 0
default points = 24
default survival = 0
default cup_distance = 0

default urko_trust = 0
default urko_jealousy = 0

default first_language_choice = ""
default winter_choice = ""
default derby_mood = ""

# Persistent unlock flags
default persistent.roma_summer_unlock = False
default persistent.future_unlock = False
default persistent.xmas_unlock = False
default persistent.threefourteen_unlock = False
default persistent.key_before_unlock = False
default persistent.derby_if_unlock = False


image pamplona_menu = "images/pamplona.png"


label start:

    scene black
    with fade

    show expression "images/pamplona.png" at fit_screen
    with dissolve

    menu:
        "请选择："

        "主线":
            jump chapter_1

        "EXTRA":
            jump extra_menu

        "DLC":
            jump dlc_menu

# ============================================================
# CHAPTER 1: 意大利人
# ============================================================

label chapter_1:

    scene black
    with fade

    n "第一章：第一次见面"
    n "那天是比赛日。"
    n "奥萨苏纳时隔10年再次联赛赛季半程客场0分，"
    n "球迷极度悲观，客场国王杯的皇社，算是一个很好的提振士气的机会。"
    n "利希下课的词条已经随处可见。"
    n "我自己没怎么看，反而更加认真工作。"
    n "毕竟在西班牙待的再久，终究还是工作重要些。"
    n "赛前情报，那个皇社自己培养的教练，赛季初顶替阿尔瓜西尔的人下课，从德国找来了一个美国人。"
    n "叫马塔拉佐？"
    n "研究了几个晚上，除去马塔拉佐在霍芬海姆时期被各种数据平台上被录入的诡异阵型，我得出一个结论。"
    n "于是第一次见面时，我很自然地选择了意大利语。"

    l "Piacere."
    n "很高兴认识你。"

    n "马塔拉佐停了半秒。"
    n "不是没听懂。"
    n "更像是大脑还停在英语，突然被人切回了意大利语。"

    m "……抱歉。"

    l "……"

    menu:
        "我："

        "换英语":
            $ trust += 1
            $ first_language_choice = "polite"
            l "很高兴认识你。"
            m "我也是。"
            n "他像是终于把工作语言切了回来。"

        "继续用意大利语试探":
            $ italian += 1
            $ tease += 1
            $ first_language_choice = "italian"
            l "Non parli italiano?"
            n "您不说意大利语？"
            m "会——只是刚刚没反应过来。"
            l "……您难道不是意大利背景？"
            m "是。问题是很少用。"
            n "他说得很认真，反而有点好笑。"

        "震惊":
            $ tease += 2
            $ first_language_choice = "tease"
            l "您听不懂意大利语？"
            m "小时候经常有人这么说。"
            n "他没有生气。"
            n "反而笑了一下。"
            n "那一秒，利希意识到这个人可能比录像看起来难对付。"
            n "毕竟是可以在当时的俱乐部高层内斗的情况下，能大比分赢过拜仁的前霍芬海姆主教练。"


        "假装什么都没发生":
            $ anger += 1
            $ first_language_choice = "awkward"
            n "利希按流程礼貌的笑了笑，握手回到主队替补席，但是听到一句嘟囔："
            m "这可能更安全一点。"
            l "安全。"
            n "这个词让我稍微顿了顿。"

    n "比赛开始。"
    n "球员们比我更清楚，如果主场再输给皇家社会，会发生什么。"
    n "在米兰达的时候，贝尼托和伊塞塔，以及现在已经在法国的帕尼切利吹过牛，"
    n "贝尼托当时主要是和伊塞塔争论那个亘古不变的问题："
    b "每一个纳瓦拉人都想加盟奥萨苏纳。"
    h"（看傻子的眼神）（15岁从奥萨苏纳加盟毕尔巴鄂竞技）"
    n "以及贝尼托是因为hugo被挖到毕尔巴鄂，被奥萨苏纳报复性在毕包卫星队挖来的五位球员之一。"
    n "潘普洛纳的球迷们，一直期待着黄金一代的重现。"
    b "当时我也在队里，真的特别厉害的一线队球员们。"
    b "hugo当时国王杯半决赛的时候还在呢，抱着pablo哭哈哈哈哈哈哈。"
    n "每次一提及巴勃罗-伊巴涅斯，"
    h"（要哭了）pablico....."
    n "对，这就是纳瓦拉顶级兄控，乌戈-林孔，我在米兰德斯时最好的右后卫。"
    n "当时的米兰德斯......"
    n "就差一点。"

    n "记忆又切到第一次记者问到那场附加赛决赛，下午刚到训练场，贝尼托来了。"
    b "教练，你不要老是说米兰德斯，不要理记者们问那些事，球迷们不喜欢。"
    b "潘普洛纳是潘普洛纳，纳瓦拉是纳瓦拉，奥萨苏纳是奥萨苏纳。"

    n "意识回到现在。"

    menu:
        "半场2-0领先，我决定："

        "后撤":
            $ anger += 1
            n "下半场8分钟就被扳平。"
            n "victor不知所措地看向我，我喊他往中路收。"
            n "那种感觉又出现了。"
            n "victor还小，还知道看教练，其他人表现出自己的Arrepentimiento，很奇怪的感觉。"
            n "我真的和去年一样，控制得了更衣室吗...？"
            n "<请注意：不要过多回忆米兰德斯>"

        "鼓励大家加油":
            $ tease += 1
            l "回防！回访！"
            n "但是下半场开场没多久就被扳平。"
            n "我只能继续鼓励。"
            n "再过一会，加兰手球送点，好在艾托尔扑出奥亚萨瓦尔的点球。"

    n "最后从0-2的领先，进入了点球。"
    n "全队正经踢过点球的，"
    n "budi正在以一种极其诡异的眼神和埃雷拉眼神交流。"
    n "budi已经被换下，嗯对，国王杯上的是艾托尔。"
    n "所以其实屁用不得。"
    n "甚至我们都没排点球手。"
    n "行。"

    menu:
        "罚进最后一个点就能保留晋级希望，我决定："

        "主动上后卫亚历杭德罗-卡泰纳":
            $ anger += 1
            n "卡泰纳丢点。"
            n "皇家社会逆转晋级，我和所有人握手之后，直接离开了球场。"
            n "包括马塔拉佐。"

        "让球员自己选谁上":
            $ tease += 1
            n "卡泰纳选择他去。"
            n "因为知道卡泰纳前两年对阵皇家社会的致命红牌导致错失晋级，我有些担心，"
            n "但是鲁文让出来了。"
            n "丢点。"

    n "我对那天的唯一的记忆就剩赛后鼓励球员们专心联赛了。"
    n "但是国王杯决赛，欧洲的梦想再次被掩盖。"
    n "那时我还不知道，"
    n "我是亲手葬送这一切的人，"
    n "以及被广泛认为是阴阳怪气的那句，"
    n "你们很快就会回到欧洲的。"

    n "Cuidado con los vestuarios del Sadar."
    n "小心萨达尔球场的更衣室。"
    n "以及当时并未被注意到的，那个皇家社会的新boss，在人群中看向我的目光。"

scene black
with fade

n "感谢游玩Despues de San Fermin试玩版。"

menu:

    "选择："

    "返回主菜单":
        jump start

    "进入 EXTRA":
        jump extra_menu

    "进入 DLC":
        jump dlc_menu


# ============================================================
# CHAPTER 2: 职业熟人
# ============================================================

label chapter_2:

    scene black
    with fade

    n "第二章：职业熟人"
    n "第二次见到马塔拉佐，是在联赛。"
    n "皇家社会客场。"
    n "赛前握手区，灯光很白。"
    n "利希本来准备按普通流程打招呼。"
    n "结果马塔拉佐先开口了。"

    m "Buonasera."

    n "发音有一点硬。"
    n "像训练过。"
    n "也像临场背出来。"

    menu:
        "我："

        "忍住不笑":
            $ trust += 1
            l "Buonasera."
            n "马塔拉佐看起来明显放心了。"

        "直接笑出来":
            $ tease += 2
            l "你回去练了？"
            m "练了一点。"
            l "练得挺明显。"
            m "这么糟？"
            l "很努力。"
            n "他笑了一下。"
            n "这次不是社交礼貌。"

        "切回英语":
            $ anger += 1
            l "正常说就行。"
            m "你是在救我。"
            l "我是在救我的耳朵。"
            m "公平。"

        "用西语回":
            $ football += 1
            l "Buenas noches."
            m "这个我听懂了。"
            l "恭喜。"

    n "比赛踢得很紧。"
    n "皇家社会控球。"
    n "奥萨苏纳逼抢。"
    n "第六十七分钟，马塔拉佐在场边做了一个手势。"
    n "利希看懂了。"
    n "那不是换人。"
    n "是压迫方向调整。"

    menu:
        "我选择："

        "立刻跟着调整":
            $ football += 2
            n "我让边路收回来。"
            n "三分钟后，局面重新稳住。"

        "不动，观察他第二步":
            $ trust += 1
            $ football += 1
            n "我没有急着改。"
            n "他看了过来。"
            n "像知道我在等。"

        "故意反着来":
            $ tease += 1
            n "我压了另一侧。"
            n "马塔拉佐愣了一下。"
            n "然后笑了。"

    n "比赛最后 1:1。"
    n "不算好。"
    n "也不算坏。"
    n "赛后通道里，他递来一份文件。"

    m "你上次把这个落在会议室了。"

    l "你带了多久？"

    m "久到看起来很负责。"

    l "……谢谢。"

    n "这就是第一条 WhatsApp 的来源。"
    n "不是暧昧。"
    n "是文件。"
    n "非常无聊。"
    n "也非常合理。"

    n "晚上，手机亮起。"

    m "比赛不错。你的文件也活下来了。"

    menu:
        "我回复："

        "谢谢":
            $ trust += 1
            l "谢谢。"
            m "很职业。"
            l "当然。"

        "比赛一般":
            $ football += 1
            l "比赛一般。"
            m "你标准很高。"
            l "你的意大利语标准比较低。"
            m "这个也是真的。"

        "别借文件聊天":
            $ tease += 2
            l "别借文件聊天。"
            m "那我下次得换个借口。"
            l "你可以不要有下次。"
            m "记下了。暂时不采纳。"

        "不回":
            $ anger += 1
            n "我把手机扣过去。"
            n "十分钟后。"
            m "这么糟？"
            n "我还是没回。"

    n "从那天开始，他们偶尔会聊。"
    n "大多数时候是足球。"
    n "阵型。"
    n "比赛。"
    n "裁判。"
    n "偶尔是语言。"
    n "利希发现马塔拉佐的意大利语不是不会。"
    n "只是像一扇很久没推开的门。"
    n "马塔拉佐也发现利希只在想逗人的时候才切意大利语。"
    n "于是很公平。"

    jump chapter_3


# ============================================================
# CHAPTER 3: 罗马冬日，分歧点
# ============================================================

label chapter_3:

    scene black
    with fade

    n "第三章：罗马冬日"
    n "冬歇期。"
    n "利希短暂回了一趟罗马。"
    n "这本来不该成为任何事件。"
    n "但那天罗马下雪了。"
    n "很少见。"
    n "雪落在窗边，灯光变得很软。"

    n "手机亮起。"

    m "罗马冷吗？"

    l "你自己不会看天气？"

    m "天气软件不会用三种语言骂我。"

    menu:
        "我："

        "回他照片":
            $ soft += 1
            n "我随手拍了一张窗外。"
            l "下雪了。"
            m "我知道。"
            l "那你还问。"
            m "想听你说。"

        "只回一句冷":
            $ anger += 1
            l "冷。"
            m "听起来很严重。"
            l "你很烦。"

        "问他圣塞冷不冷":
            $ trust += 1
            l "圣塞冷不冷？"
            m "看起来比罗马好一点。"
            l "少骗人。"

        "不回":
            $ anger += 1
            n "我没回。"
            n "五分钟后。"
            m "还活着？"
            n "很烦。"

    n "凌晨。"
    n "他打来视频。"

    m "开视频。"

    l "不要。"

    m "我想看看雪。"

    l "天气预报没有雪？"

    m "不一样。天气预报里没有你。"

    menu:
        "我决定："

        "开视频":
            $ soft += 2
            $ trust += 1
            n "我还是开了视频。"
            m "你的头发很灾难。"
            l "关你什么事。"
            m "练了一点。"

        "镜头对窗外":
            $ tease += 1
            n "我把镜头对准窗外。"
            m "那是罗马。"
            l "你不是要看雪？"
            m "我说的是罗马人。"
            l "滚。"

        "只露脸一秒":
            $ tease += 2
            n "我把镜头转回来一秒。"
            n "然后又转走。"
            m "太短了。"
            l "你要求很多。"
            m "只对重要的事这样。"

        "挂掉":
            $ anger += 2
            n "我挂了。"
            n "三秒后，消息跳出来。"
            m "很没礼貌。"
            l "职业边界。"
            m "凌晨一点半的职业边界？"

    n "视频最后还是接着。"
    n "话题从天气滑到足球。"
    n "又从足球滑到语言。"
    n "马塔拉佐试着说意大利语。"
    n "说得很慢。"
    n "像怕踩错每一个音节。"

    m "Mi... sei mancato."

    n "我想你了。"

    n "利希愣了一下。"

    menu:
        "我最后说："

        "你真的很烦":
            $ tease += 1
            $ winter_choice = "annoying"
            l "你真的很烦。"
            m "你没挂电话。"
            l "我手滑。"
            m "四十分钟也算早点睡？"
            n "【？？？已被发现】"
            $ persistent.xmas_unlock = True
            jump m_end


        "早点睡":
            $ trust += 1
            $ winter_choice = "sleep"
            l "早点睡。"
            m "你先睡。"
            l "你先。"
            m "职业僵局。"
            $ persistent.threefourteen_unlock = True
            n "【？？？已被发现】"
            n "深夜，会有来自圣塞巴斯蒂安的客人吗？"
            jump sleep_end


        "再说一句意大利语":
            $ italian += 3
            $ soft += 2
            $ trust += 1
            $ winter_choice = "italian"
            l "再说一句意大利语。"
            m "你在考我？"
            l "对。"
            m "Allora... resta al caldo."
            n "那就待在暖和的地方。"
            l "还行。"
            m "只是还行？"
            l "及格。"
            $ persistent.roma_summer_unlock = True
            n "【？？？已被发现】"
            n "某个夏天，在远处亮了一下。"
            jump winter_end

label m_end:

    if tease >= 1:
       $ persistent.xmas_unlock = True

    n "夜深了,利希已经睡着，但是视频仍然开着。"
    n "马塔拉佐依旧在另一头办公，可是一转眼，"
    n "人没了。"

    menu:
        "继续："

        "继续主线":
            jump chapter_4

        "打开 EXTRA 看看":
            jump extra_menu


label sleep_end:

    if trust >= 1:
       $ persistent.threefourteen_unlock = True

    n "夜深了"
    n "利希已经睡着，但是视频仍然开着。"
    n "视频旁的男人笑了一下。"

    menu:
        "继续："

        "继续主线":
            jump chapter_4

        "打开 EXTRA 看看":
            jump extra_menu


label winter_end:

    if italian >= 3:
        $ persistent.future_unlock = True

    n "罗马冬日结束后。"
    n "利希回到潘普洛纳。"
    n "而现实也回到了原来的重量。"

    menu:
        "继续："

        "继续主线":
            jump chapter_4

        "打开 EXTRA 看看":
            jump extra_menu

# ============================================================
# MEMORY STORY: Presagio
# ============================================================

label future_special:

    scene rain_bg
    with fade

    n "【回忆特典】"

    n "Presagio"

    n "预感"

    n "凌晨 2:17。"

    n "视频通话已经结束。"

    n "马塔拉佐本来准备睡觉。"

    n "手机亮了一下。"

    n "没有消息。"

    n "只是下意识。"

    n "他打开了定位。"

    n "……"

    n "空白。"

    n "最后一次记录停在两小时前。"

    m "？"

    n "他皱起眉。"

    n "电话无人接听。"

    n "消息没有回复。"

    n "第二个电话。"

    n "第三个电话。"

    n "依旧没有人接。"

    n "某种不祥的预感开始蔓延。"

    m "阿莱西奥。"

    n "没有回应。"

    menu:
        "马塔拉佐决定："

        "去找他":
            jump presagio_find

        "继续等消息":
            jump presagio_wait


label presagio_find:

    scene rain_bg
    with fade

    n "五分钟后。"

    n "车灯亮起。"

    n "圣塞巴斯蒂安在雨里退到身后。"

    n "高速路上很空。"

    n "雨刷来回摆动。"

    n "马塔拉佐没有开音乐。"

    n "也没有再打电话。"

    n "有些事情，如果连续三次没有回应，就不该继续等。"

    n "潘普洛纳。"

    n "凌晨 3:06。"

    n "公寓里没人。"

    n "灯是关着的。"

    n "外套不在。"

    n "手机也不在。"

    n "但床铺乱着。"

    n "像有人原本睡过。"

    m "……"

    n "他站在门口。"

    n "忽然意识到。"

    n "人不是没回来。"

    n "是回来过。"

    n "又离开了。"

    n "雨还在下。"

    n "马塔拉佐转身下楼。"

    n "第二个地点。"

    n "训练基地。"

    n "铁门外没有人。"

    n "停车场也没有人。"

    n "只有雨水顺着灯柱往下流。"

    n "他往旁边走了几步。"

    n "然后停住。"

    n "铁栏边。"

    n "有人蹲在那里。"

    n "黑色外套已经湿透。"

    n "鞋不见了。"

    n "手指抓着栏杆。"

    n "像根本不知道自己在哪里。"

    m "阿莱西奥。"

    n "没有回应。"

    m "利希。"

    n "还是没有。"

    n "马塔拉佐蹲下来。"

    n "没有立刻碰他。"

    n "他知道利希不喜欢被碰。"

    n "尤其是在状态不对的时候。"

    n "但现在不是询问喜好的时候。"

    m "看我。"

    n "那双眼睛慢慢抬起来。"

    n "空的。"

    n "像还在梦里。"

    l "……回家。"

    n "声音很轻。"

    n "被雨打碎。"

    m "嗯。"

    n "他把外套脱下来，裹住人。"

    m "先回家。"

    n "他没有说。"

    n "是我的。"

    n "但抱起来的时候。"

    n "动作已经替他说了。"

    n "【Presagio 完】"

    jump extra_menu


label presagio_wait:

    scene black
    with fade

    n "马塔拉佐最终没有出门。"

    n "他把手机放回桌上。"

    n "告诉自己。"

    n "成年人不该被一种没有证据的预感控制。"

    n "凌晨 3:14。"

    n "手机没有响。"

    n "凌晨 4:02。"

    n "依旧没有。"

    n "天亮以后。"

    n "助教的电话打了过来。"

    n "那一瞬间。"

    n "他忽然知道。"

    n "有些预感。"

    n "不是为了证明自己正确。"

    n "而是为了让人来得及。"

    n "【Presagio：错过】"

    jump extra_menu
# ============================================================
# MEMORY STORY: Le 3:14
# ============================================================

label threefourteen_special:

    scene bed
    with fade

    n "【回忆特典】"

    n "Le 3:14"

    n "凌晨三点十四分。"

    n "视频通话没有挂断。"

    n "利希已经睡着了。"

    n "屏幕那头，只剩下很轻的呼吸声。"

    n "马塔拉佐原本应该挂掉。"

    n "但他没有。"

    n "他只是把电脑往旁边挪了一点。"

    n "继续处理白天没看完的文件。"

    n "圣塞巴斯蒂安的夜很安静。"

    n "安静到他能听见视频里被子摩擦的声音。"

    l "……"

    n "屏幕里的人翻了一下身。"

    n "手指抓住被角。"

    n "像抓住什么会离开的东西。"

    m "……阿莱西奥？"

    n "没有回答。"

    n "他睡得很沉。"

    n "但眉头皱着。"

    n "像梦里也没有真正放松。"

    l "Sei qui..."

    n "你在。"

    n "梦话。"

    n "意大利语。"

    n "太轻。"

    n "轻到几乎要被电流声吞掉。"

    n "马塔拉佐停下手里的笔。"

    m "我在。"

    n "他说完才意识到，对方根本听不见。"

    n "可是屏幕里的人像是安心了一点。"

    n "眉心慢慢松开。"

    n "马塔拉佐看了很久。"

    n "久到文件上的字开始失去意义。"

    n "久到凌晨三点十四分。"

    n "手机亮了一下。"

    n "没有新消息。"

    n "只是屏幕自动提醒他时间。"

    n "03:14。"

    n "这个数字莫名其妙地留了下来。"

    n "像一枚很小的钉子。"

    n "钉进夜里。"

    menu:
        "马塔拉佐决定："

        "继续看着他":
            jump threefourteen_watch

        "挂断视频":
            jump threefourteen_hangup


label threefourteen_watch:

    scene bed
    with fade

    n "马塔拉佐没有挂断。"

    n "他靠回椅背。"

    n "把声音调低。"

    n "又把电脑屏幕调暗。"

    n "像这样就不会吵醒一个远在潘普洛纳的人。"

    n "这很荒唐。"

    n "他知道。"

    n "但成年人最可怕的地方，就是会给荒唐找到很多合理解释。"

    m "只是确认你睡着。"

    n "他说给自己听。"

    n "屏幕里的人没有反驳。"

    n "于是这个理由暂时成立。"

    n "凌晨四点。"

    n "利希又动了一下。"

    l "Non andare..."

    n "别走。"

    n "马塔拉佐的手停住。"

    n "这一次，他很久都没有说话。"

    n "他突然明白。"

    n "有些话。"

    n "清醒的时候问不到。"

    n "睡着以后，反而会自己掉出来。"

    m "我不走。"

    n "他说得很轻。"

    n "像怕惊动梦。"

    n "天快亮的时候，视频终于断了。"

    n "不是他挂的。"

    n "是网络自己撑不住了。"

    n "屏幕黑下去。"

    n "房间里安静得过分。"

    n "马塔拉佐坐了一会。"

    n "然后拿起手机。"

    n "输入。"

    m "早安。"

    n "删掉。"

    m "睡得好吗？"

    n "删掉。"

    m "下次别开着视频睡。"

    n "还是删掉。"

    n "最后，他什么都没发。"

    n "只是把 03:14 记了下来。"

    n "【Le 3:14 完】"

    jump extra_menu


label threefourteen_hangup:

    scene black
    with fade

    n "马塔拉佐伸手。"

    n "指尖停在挂断键上。"

    n "这才是正确做法。"

    n "尊重边界。"

    n "保持距离。"

    n "像两个成年人一样。"

    n "他按了下去。"

    n "屏幕黑了。"

    n "房间里瞬间安静下来。"

    n "安静得有点过分。"

    n "十分钟后。"

    n "他重新拿起手机。"

    n "没有消息。"

    n "没有未接来电。"

    n "什么都没有。"

    n "可他还是觉得，刚才有什么东西被他亲手关在了屏幕另一边。"

    n "凌晨三点十四分。"

    n "他第一次后悔自己太像一个正常人。"

    n "【Le 3:14：错过】"

    jump extra_menu

# ============================================================
# HIDDEN ROUTE: Roma d'estate
# ============================================================

label roma_summer_route:

    scene black
    with fade

    n "【隐藏路线】"
    n "Roma d'estate"
    n "罗马夏日"
    n "这是一段本不该发生的夏天。"

    n "六月。"
    n "罗马 38℃。"
    n "热得连石墙都像在呼吸。"
    n "利希回罗马短住。"
    n "他以为这次终于能安静几天。"
    n "门铃响了。"

    l "……？"

    n "门外。"
    n "马塔拉佐戴着太阳镜。"
    n "黑 T。"
    n "行李箱。"
    n "像某种完全不合理的度假事故。"

    l "你为什么在罗马？？？"

    m "独处时间。"

    l "你把冬天那句话记到现在？"

    m "有些句子很重要。"

    menu:
        "我："

        "让他进来":
            $ soft += 2
            l "进来。别站门口丢人。"
            m "这是允许。"
            l "这是嫌你挡路。"

        "先骂他":
            $ tease += 2
            l "你疯了。"
            m "练了一点。"
            l "你每次都这个答案。"
            m "它一直是真的。"

        "问他住哪":
            $ trust += 1
            l "你住哪？"
            m "酒店。"
            l "很好。"
            m "你听起来有点失望。"
            l "没有。"

    n "罗马夏天和冬天不一样。"
    n "冬天适合把话藏在雪里。"
    n "夏天不行。"
    n "太热。"
    n "什么都会被晒出来。"

    n "第一天，他们去吃 gelato。"
    n "马塔拉佐选了太甜的口味。"
    n "利希嘲笑他五分钟。"

    menu:
        "夜里，我选择："

        "带他去台伯河边":
            $ soft += 2
            n "夜风终于凉了一点。"
            m "你是在这里长大的？"
            l "算是。"
            m "难怪你骂人这么漂亮。"
            l "你闭嘴。"

        "带他去小时候的街区":
            $ trust += 2
            n "巷子窄。"
            n "灯很旧。"
            n "马塔拉佐走得很慢，像怕踩坏什么。"
            m "谢谢你带我看。"
            l "少突然认真。"

        "哪都不去，躲空调":
            $ tease += 1
            n "空调声音很吵。"
            n "两个人坐在客厅。"
            n "谁都没有提为什么不各回各的地方。"

    n "第三天晚上，空调坏了。"
    n "罗马热得像一只不肯睡觉的兽。"
    n "凌晨两点，利希去厨房喝水。"
    n "马塔拉佐也在那里。"

    m "睡不着？"

    l "你也没睡。"

    m "我在等，看你会不会出来。"

    l "你这句话听起来很可疑。"

    m "这是实话。更糟。"

    n "那一夜他们聊了很久。"
    n "不是调情。"
    n "是足球。"
    n "是教练。"
    n "是赢球之后没人知道的疲惫。"
    n "也是输球之后不得不第二天继续工作的荒谬。"

    menu:
        "天亮前，我说："

        "你明天就走吧":
            $ anger += 1
            l "你明天就走吧。"
            m "你想让我走吗？"
            l "我在陈述事实。"
            m "你今晚不太会说事实。"

        "再待一天":
            $ soft += 3
            l "再待一天。"
            n "马塔拉佐很久没说话。"
            m "用意大利语？"
            l "别得寸进尺。"

        "Resta ancora":
            $ italian += 3
            $ soft += 4
            l "Resta ancora."
            n "再待一会。"
            n "马塔拉佐愣住。"
            m "你清醒的时候说了。"
            l "所以？"
            m "所以我有麻烦了。"

    n "【隐藏路线：夏后 开启】"
    n "这个夏天以后，某些德比注定不会再按原来的方式发生。"

    return


# ============================================================
# CHAPTER 4: 保级战争
# ============================================================

label chapter_4:

    scene black
    with fade

    n "第四章：保级战争"
    n "二月。"
    n "奥萨苏纳，24 分。"
    n "第 17。"
    n "降级区就在身后。"
    n "会议室灯开到凌晨。"
    n "积分榜、伤病报告、赛程表，全摊在桌上。"
    n "贝尼托的名字后面还是 unavailable。"
    n "不是刚伤。"
    n "是已经缺了太久。"
    n "球队早就开始习惯没有他。"
    n "但习惯不代表不疼。"

    s "我们得开始算分了。"

    l "安全线呢？"

    s "今年可能要 40。甚至 42。"

    n "手机震了一下。"
    n "Matarazzo。"

    m "积分榜怎么样？"

    menu:
        "我："

        "不看":
            $ cup_distance += 1
            n "我没有看。"
            n "现在没有时间处理别人的关心。"

        "回：很烂":
            $ trust += 1
            l "很烂。"
            m "真诚。"
            l "你问的。"

        "回：关你什么事":
            $ tease += 1
            l "关你什么事。"
            m "一点职业好奇。"
            l "少来。"

        "回：你先管好国王杯":
            $ football += 1
            l "你先管好国王杯。"
            m "在试。"

    n "第二天，战术会。"
    n "保级队没有浪漫。"
    n "只有选择。"

    menu:
        "下一轮，我选择："

        "稳守反击":
            $ survival += 2
            $ points += 1
            n "比赛不好看。"
            n "但拿到一分。"
            n "保级路上，一分也能救命。"

        "高位逼抢":
            $ football += 2
            $ morale += 1
            n "前二十分钟很好。"
            n "后面很累。"
            n "最后 2:2。"
            $ points += 1

        "定位球搏命":
            $ survival += 1
            $ morale += 1
            n "角球。混战。第二点。"
            n "球进了。"
            $ points += 3

        "五后卫保命":
            $ survival += 1
            $ anger += 1
            n "媒体骂得很难听。"
            n "但更衣室知道。"
            n "有些比赛就是不能死。"
            $ points += 1

    n "发布会。"

    r "你觉得奥萨苏纳还能保级吗？"

    menu:
        "我回答："

        "稳住军心":
            $ morale += 2
            l "我们会留下。"
            r "你确定？"
            l "我必须确定。"

        "阴阳怪气":
            $ tease += 1
            l "如果你有更好的积分，我很愿意听。"
            n "记者席安静了两秒。"

        "承认困难":
            $ trust += 1
            l "很难。"
            l "但难不代表结束。"

        "发疯一点":
            $ anger += 1
            l "下一场赢了你们是不是就换个问题？"
            n "新闻标题立刻有了。"

    n "三月。"
    n "皇家社会进入国王杯决赛。"
    n "新闻刷屏。"
    n "马塔拉佐发来消息。"

    m "我们进决赛了。"

    menu:
        "我："

        "回恭喜":
            $ trust += 1
            l "恭喜。"
            m "谢谢。"
            n "很普通。"
            n "普通到有点陌生。"

        "只点开，不回":
            $ cup_distance += 2
            n "已读。"
            n "不回。"
            n "不是故意。"
            n "只是桌上还有下一轮对手的录像。"

        "回：我没空":
            $ anger += 1
            l "我没空。"
            m "我知道。"
            n "这句“我知道”比恭喜更难处理。"

    n "现实把人压得很薄。"
    n "薄到感情只能夹在赛程表和伤病报告之间。"

    if points >= 28:
        $ persistent.key_before_unlock = True

    jump chapter_5


# ============================================================
# CHAPTER 5: 德比失踪夜（现实版）
# ============================================================

label chapter_5:

    scene black
    with fade

    n "第五章：德比失踪夜"
    n "德比那天，利希已经连续三晚没睡好。"
    n "不是因为马塔拉佐。"
    n "至少不全是。"
    n "积分榜像一张贴在眼皮后的纸。"
    n "闭眼也还在那里。"

    n "赛前，手机亮起。"

    m "祝你好运。"

    menu:
        "我："

        "不回":
            $ derby_mood = "cold"
            n "我没回。"

        "回：你也是":
            $ derby_mood = "soft"
            $ trust += 1
            l "你也是。"
            m "很职业。"

        "回：少来":
            $ derby_mood = "tease"
            $ tease += 1
            l "少来。"
            m "这才像你。"

    n "比赛踢得很硬。"
    n "没有罗马冬日。"
    n "没有玩笑。"
    n "只有铲断、回追、第二落点和裁判哨。"

    menu:
        "下半场，我选择："

        "保平":
            $ survival += 1
            $ points += 1
            n "0:0。"
            n "不好看。"
            n "但活着。"

        "赌一把赢":
            $ football += 2
            n "第八十七分钟，反击差一点成了。"
            n "下一分钟，皇家社会也差一点杀死比赛。"
            n "最后还是平。"
            $ points += 1

        "换上年轻人":
            $ morale += 2
            n "年轻人跑得很凶。"
            n "全场起立鼓掌。"
            n "比分没有变，但更衣室像活了一点。"
            $ points += 1

    n "赛后，利希没去看马塔拉佐。"
    n "他只想回更衣室。"
    n "但通道拐角。"
    n "有人等在那里。"

    m "你看起来糟透了。"

    l "谢谢。你也很烦。"

    m "这点倒是一直没变。"

    menu:
        "我："

        "让他走":
            $ anger += 1
            l "你该去发布会。"
            m "我知道。"
            l "那就去。"
            n "他没动。"

        "问他为什么来":
            $ soft += 1
            l "你来干什么。"
            m "确认你还站得住。"
            l "我不是小孩。"
            m "不。你更糟，只是更会装。"

        "沉默":
            $ trust += 1
            n "我没说话。"
            n "他也没急。"
            n "成年人最糟糕的一点。"
            n "就是他们知道什么时候不该追问。"

    n "工作人员在远处喊。"

    s "Mister！发布会！"

    n "马塔拉佐没有回头。"

    m "五分钟。"

    l "你又失踪。"

    m "不是所有人都有。"

    n "这一句话太轻。"
    n "轻得像没有落地。"
    n "但利希还是听见了。"

    if soft >= 5 or trust >= 6:
        $ persistent.derby_if_unlock = True

    menu:
        "最后，我："

        "推开他":
            l "别挡路。"
            m "好。"
            n "他让开。"
            n "反而更难受。"

        "低声说谢谢":
            $ soft += 2
            l "谢谢。"
            m "为什么？"
            l "别让我解释。"
            m "好。"

        "用意大利语骂他":
            $ italian += 1
            l "Sei fastidioso."
            n "你很烦。"
            m "这句我听懂了。"

    n "那晚没有视频。"
    n "没有开车。"
    n "没有钥匙。"
    n "只有两个主教练，各自回到自己的现实里。"

    jump chapter_6


# ============================================================
# CHAPTER 6: 国王杯冠军夜
# ============================================================

label chapter_6:

    scene black
    with fade

    n "第六章：国王杯冠军夜"
    n "皇家社会夺冠那天，潘普洛纳在下雨。"
    n "奥萨苏纳第二天还有训练。"
    n "利希看了十分钟决赛。"
    n "然后关掉。"
    n "不是不想看。"
    n "是不敢再多看。"

    n "凌晨。"
    n "手机亮起。"

    m "我们赢了。"

    n "就两个词。"
    n "像从另一个世界传来。"

    menu:
        "我："

        "回恭喜":
            $ trust += 1
            l "恭喜。"
            m "谢谢。"
            n "对话停在这里。"
            n "礼貌得像第一章。"

        "已读不回":
            $ cup_distance += 2
            n "我看着那条消息。"
            n "最后把手机扣在桌上。"

        "只发一个杯子 emoji":
            $ tease += 1
            l "🏆"
            m "这几乎算温柔了。"
            l "别得寸进尺。"

        "关机":
            $ cup_distance += 3
            n "我关了机。"
            n "第二天醒来时，世界没有变轻。"

    n "那之后，马塔拉佐发消息的频率变低。"
    n "利希回消息的速度更低。"
    n "不是谁故意疏远。"
    n "只是一个人在庆祝冠军。"
    n "另一个人在计算保级。"
    n "成年人最残酷的距离，有时候只是赛程不同。"

    if cup_distance >= 4:
        $ persistent.future_unlock = True

    jump chapter_7


# ============================================================
# CHAPTER 7: 保级终章
# ============================================================

label chapter_7:

    scene black
    with fade

    n "第七章：保级终章"
    n "最后几轮。"
    n "每一分都像从石头缝里抠出来。"
    n "第 38 轮前。"
    n "奥萨苏纳还没完全安全。"
    n "会议室里没人说废话。"

    s "最后一场。"
    s "我们需要至少一分。"

    menu:
        "最终战术："

        "死守一分":
            $ survival += 2
            $ points += 1
            n "比赛像一场漫长的拔河。"
            n "终场哨响。"
            n "0:0。"

        "定位球抢开局":
            $ football += 2
            $ points += 3
            n "第十二分钟，角球。"
            n "混战。"
            n "球进了。"
            n "之后每一分钟都像一年。"

        "正常踢":
            $ morale += 1
            $ points += 1
            n "没有奇迹。"
            n "但也没有崩溃。"
            n "这就是保级队最奢侈的胜利。"

        "冒险进攻":
            $ football += 3
            n "场面很好。"
            n "心脏很差。"
            n "最后靠门将救了一次命。"
            $ points += 1

    if points >= 40:
        jump ending_survival
    else:
        jump ending_survival_edge


label ending_survival:

    scene black
    with fade

    n "保级成功。"
    n "没有奖杯。"
    n "没有彩带。"
    n "只有更衣室里突然安静下来的呼吸声。"
    n "利希坐了很久。"
    n "手机亮起。"

    m "你也赢了。"

    n "你也赢了。"

    menu:
        "我："

        "回他":
            l "只是留下。"
            m "有时候这更难。"
            n "利希看着这句话。"
            n "很久。"

        "不回":
            n "我没有回。"
            n "但这一次不是逃避。"
            n "只是太累了。"

    n "【主线结局：留下】"
    return


label ending_survival_edge:

    scene black
    with fade

    n "奥萨苏纳还是留下了。"
    n "惊险。狼狈。几乎称不上胜利。"
    n "但留下就是留下。"
    n "深夜。"
    n "手机亮起。"

    m "还站得住吗？"

    l "勉强。"

    m "那就算。"

    n "【主线结局：勉强站着】"
    return


# ============================================================
label dlc_menu:

    scene hoffenheim_village_1920x1080
    with fade

    centered "【DLC】"

    menu:
        "请选择 DLC："

        "Der Ketzer":
            jump dlc_heretic_demo

        "返回主菜单":
            jump start


label dlc_heretic_demo:

    scene vatican_room
    with fade

    n "【Der Ketzer】"

    n "1497年。"

    n "罗马。"

    n "教廷终于决定派人在神圣罗马帝国境内追查异端。"

    show lisci_monk at Transform(xalign=0.82, yalign=1.0, zoom=0.55)
    with dissolve

    l "所以为什么让我回罗马。"

    hide lisci_monk
    with dissolve

    n "有人把卷宗推到他面前。"

    n "目标：霍芬海姆。"

    n "前方济各会修士。"

    n "——马塔拉佐。"

    n "同一夜。"

    n "霍芬海姆。"

    show matt at Transform(xalign=0.82, yalign=1.0, zoom=0.55)
    with dissolve

    m "你要来了啊……"

    hide matt
    with dissolve

    hide matt
    with dissolve

    menu:
        "马塔拉佐决定："

        "故意留下信":
            n "他让村民把一封信送去旅店。"
            n "信上只有一句话。"
            m "罗马人，别迷路。"
            jump dlc_heretic_inn

        "暂时躲起来":
            n "他吹灭烛火。"
            m "还不是时候。"
            jump dlc_heretic_watch

label dlc_heretic_inn:

    scene medieval_inn_1920x1080
    with fade

    n "霍芬海姆。"

    n "利希抵达时，天色刚暗。"

    n "村子并无多少人，罕见几人，看见他的服饰都趋之不及。"

    n "旅馆老板像是早已知道他会来。"

    n "递来一封信。"

    n "封蜡上没有徽记。"

    n "只有一句话。"

    m "罗马人，别迷路。"

    l "……"

    l "他知道我会来。"

    jump dlc_heretic_chapter1_common

label dlc_heretic_watch:

    scene hoffenheim_village_1920x1080
    with fade

    n "霍芬海姆。"

    n "利希抵达时，村口很安静。"

    n "没有信。"

    n "也没有人承认见过马塔拉佐。"

    n "但远处二楼的窗后。"

    n "有人一直在看他。"

    show matt at Transform(xalign=0.82, yalign=1.0, zoom=0.55)
    with dissolve

    m "真的来了。"

    hide matt
    with dissolve

    jump dlc_heretic_chapter1_common

label dlc_heretic_chapter1_common:

    scene hoffenheim_village_1920x1080
    with fade

    n "第一章：霍芬海姆"

    n "从这一刻开始，利希意识到。"

    n "这次任务不会像卷宗里写得那么简单。"

    n "【待续】"

    jump dlc_menu

# EXTRA: all slots are ???. Click reveals preview sentence, then locked/unlocked.
# EXTRA: all slots are ???. Click reveals preview sentence, then locked/unlocked.
# ============================================================


label extra_menu:

    scene black
    with fade

    show expression "images/extra_bg.png" at fit_screen
    with dissolve

    centered "【EXTRA】"

    menu:
        "选择一个记忆碎片："

        "Presagio" if persistent.xmas_unlock:
            jump extra_slot_future

        "？？？" if not persistent.xmas_unlock:
            jump extra_slot_future

        "Tre e Quattordici" if persistent.threefourteen_unlock:
            jump extra_slot_threefourteen

        "？？？" if not persistent.threefourteen_unlock:
            jump extra_slot_threefourteen

        "Roma d'estate" if persistent.roma_summer_unlock:
            jump extra_slot_summer

        "？？？" if not persistent.roma_summer_unlock:
            jump extra_slot_summer

        "返回主菜单":
            jump start

label extra_slot_summer:

    scene expression "images/summer_bg.png"
    with fade

    n "「有些夏天，本不该发生。」"

    if persistent.roma_summer_unlock:

        n "【隐藏路线】"
        n "Roma d'estate"

        menu:
            "进入？"

            "进入":
                jump roma_summer_route

            "返回":
                jump extra_menu

    else:

        n "尚未解锁。"

        jump extra_menu

label extra_slot_future:

    scene rain_bg
    with fade

    n "「有人消失在凌晨三点之后。」"

    if persistent.xmas_unlock:

        n "【回忆特典】"
        n "Presagio"

        menu:
            "进入？"

            "进入":
                jump future_special

            "返回":
                jump extra_menu

    else:

        n "尚未解锁。"

        jump extra_menu

label extra_slot_threefourteen:

    scene bed
    with fade

    n "「凌晨三点，总有人还醒着。」"

    if persistent.threefourteen_unlock:

        n "【回忆特典】"
        n "Le 3:14"

        menu:
            "进入？"

            "进入":
                jump threefourteen_special

            "返回":
                jump extra_menu

    else:

        n "尚未解锁。"

        jump extra_menu

    return 
